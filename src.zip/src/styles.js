export const styles = {
  paddingX: "lg:px-12 md:px-8 px-4 ",
};
